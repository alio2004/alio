public enum Grade {
    AssistantProfessor,AssociateProfessor,Master,Coach
}
