import java.util.ArrayList;

public class Master extends Person {
    String MasterID;
    Grade masterGrade;
    ArrayList<Section> sections = new ArrayList<>();

    public Master(String name, String lName, String nationalCode , String masterID, Grade masterGrade) {
        super(name, lName, nationalCode);
        this.masterGrade = masterGrade;
        this.MasterID = masterID;
    }

    public ArrayList<Section> getSections() {
        return sections;
    }

    public void setSections(ArrayList<Section> sections) {
        this.sections = sections;
    }

    public String getMasterID() {
        return MasterID;
    }

    public void setMasterID(String masterID) {
        MasterID = masterID;
    }

    public Grade getMasterGrade() {
        return masterGrade;
    }

    public void setMasterGrade(Grade masterGrade) {
        this.masterGrade = masterGrade;
    }
}
