import java.util.ArrayList;

public class Student extends Person {
    private String studentID;
    private ArrayList<Received> received = new ArrayList<>();

    public Student(String name, String lName, String nationalCode , String studentID) {
        super(name, lName, nationalCode);
        this.studentID = studentID;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public ArrayList<Received> getReceived() {
        return received;
    }

    public void setReceived(ArrayList<Received> received) {
        this.received = received;
    }
}
