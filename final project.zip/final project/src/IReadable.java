public interface IReadable <T> {
    public abstract String objectToString(T value);
}
