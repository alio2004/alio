public class Lesson {
    private String name;
    private String lessonCode;

    public Lesson(String name, String lessonCode) {
        this.name = name;
        this.lessonCode = lessonCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLessonCode() {
        return lessonCode;
    }

    public void setLessonCode(String lessonCode) {
        this.lessonCode = lessonCode;
    }
}
