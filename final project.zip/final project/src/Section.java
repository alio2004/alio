public class Section implements IReadable<Section> {
    private String sectionCode;
    private Lesson lesson;
    private Master master;
    private String Capacity;
    private Day day;
    private String startTime;
    private String endTime;

    public Section(String sectionCode, Lesson lesson, Master master, String capacity, Day day, String startTime, String endTime) {
        this.sectionCode = sectionCode;
        this.lesson = lesson;
        this.master = master;
        Capacity = capacity;
        this.day = day;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public String getSectionCode() {
        return sectionCode;
    }

    public void setSectionCode(String sectionCode) {
        this.sectionCode = sectionCode;
    }

    public Lesson getLesson() {
        return lesson;
    }

    public void setLesson(Lesson lesson) {
        this.lesson = lesson;
    }

    public Master getMaster() {
        return master;
    }

    public void setMaster(Master master) {
        this.master = master;
    }

    public String getCapacity() {
        return Capacity;
    }

    public void setCapacity(String capacity) {
        Capacity = capacity;
    }

    public Day getDay() {
        return day;
    }

    public void setDay(Day day) {
        this.day = day;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    @Override
    public String objectToString(Section section) {
        return "A section with code "+section.getSectionCode()+" for "+section.getLesson().getName()+" with capacity of "
                +section.getCapacity()+" represented by "+section.getMaster().getlName()+" at "+section.getStartTime()+" to "+
                section.getEndTime()+" on "+section.getDay().toString();
    }
}
